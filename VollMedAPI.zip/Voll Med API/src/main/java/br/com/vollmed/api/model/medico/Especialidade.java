package br.com.vollmed.api.model.medico;

public enum Especialidade {

    ORTOPEDIA,
    GINECOLOGIA,
    ODONTOLOGIA,
    OTORRINOLARINGOLOGIA

}
